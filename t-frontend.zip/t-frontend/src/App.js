// import React, { useState, useEffect } from "react";
// import logo from "./logo.svg";
// import "./App.css";
// import axios from "axios";
// import "./mycss.css";
// import Edit from "./Edit.js";
// function App() {
//   const [user, setUser] = useState({
//     name: "",
//     email: "",
//     age: "",
//     department: "",
//     gender: "",
//   });

//   const [users, setUsers] = useState([]);
//   const [viewUser, setViewUser] = useState(null);
//   const [isPopupVisible, setIsPopupVisible] = useState(false);

//   const [isEding, setIsEditing] = useState(false);
//   const [editUser, setEditUser] = useState(null);

//   const handleChange = (e) => {
//     const { name, value } = e.target;
//     setUser({
//       ...user,
//       [name]: value,
//     });
//   };

//   const handleSubmit = async (e) => {
//     e.preventDefault();
//     try {
//       await axios.post("http://localhost:5000/api/users", user);
//       alert("User data submitted ");
//     } catch (error) {
//       console.log("we have error", error);
//     }
//   };

//   const fetchUsers = async () => {
//     try {
//       const response = await axios.get("http://localhost:5000/api/users");
//       setUsers(response.data);
//     } catch (error) {
//       console.log("we have error", error);
//     }
//   };

//   const handleDelete = async (id) => {
//     try {
//       await axios.delete(`http://localhost:5000/api/userdelete/${id}`);
//       alert("User data deleted ");
//       fetchUsers();
//     } catch (error) {
//       console.log("there wase error during deleting user data", error);
//     }
//   };

//   const handleView = (user) => {
//     setViewUser(user);
//     setIsPopupVisible(true);
//   };
//   const handleEdit = (user) => {
//     setEditUser(user);
//     setIsEditing(true);
//   };

//   const handleEditSubmit = async (e) => {
//     e.preventDefault();
//     try {
//       await axios.put(
//         `http://localhost:5000/api/users/${editUser.Id}`,
//         editUser
//       );
//       alert("User data updated successfully");
//       fetchUsers();
//       setIsEditing(false);
//     } catch (error) {
//       console.error("There was an error updating the user data!", error);
//     }
//   };

//   const closePopup = () => {
//     setIsPopupVisible(false);
//     setViewUser(null);
//   };
//   useEffect(() => {
//     fetchUsers();
//   }, []);

//   const tableStyle = {
//     // borderCollapse :'collapse',
//     width: "100%",
//     marginTop: "30px",
//   };

//   const thtdStyle = {
//     border: "1px solid red",
//     padding: "8px",
//     textAlign: "left",
//   };

//   return (
//     <div className="App">
//       <h2>Send Users To database</h2>
//       <form onSubmit={handleSubmit}>
//         <div>
//           <label>Name</label>
//           <input
//             type="text"
//             name="name"
//             required
//             value={user.name}
//             onChange={handleChange}
//           />
//         </div>

//         <div>
//           <label>Email</label>
//           <input
//             type="text"
//             name="email"
//             required
//             value={user.email}
//             onChange={handleChange}
//           />
//         </div>

//         <div>
//           <label>Age</label>
//           <input
//             type="number"
//             name="age"
//             required
//             onChange={handleChange}
//             value={user.age}
//           />
//         </div>

//         <div>
//           <label>Department</label>
//           <input
//             type="text"
//             name="department"
//             onChange={handleChange}
//             value={user.department}
//           />
//         </div>

//         <div>
//           <label>Gender</label>
//           <div>
//             <input
//               type="radio"
//               id="male"
//               name="gender"
//               value="Male"
//               onChange={handleChange}
//               required
//               checked={user.gender === "Male"}
//             />
//             <label>Male</label>
//           </div>

//           <div>
//             <input
//               type="radio"
//               id="female"
//               name="gender"
//               value="Female"
//               onChange={handleChange}
//               required
//               checked={user.gender === "Female"}
//             />
//             <label>Female</label>
//           </div>

//           <div>
//             <input
//               type="radio"
//               id="other"
//               name="gender"
//               value="Other"
//               onChange={handleChange}
//               required
//               checked={user.gender === "Other"}
//             />
//             <label>Other</label>
//           </div>
//         </div>

//         <button type="submit">Submit</button>
//       </form>

//       <h2>Get users from database</h2>
//       <table style={tableStyle}>
//         <thead>
//           <tr>
//             <th style={thtdStyle}>ID</th>
//             <th style={thtdStyle}>Name</th>
//             <th style={thtdStyle}>Email</th>
//             <th style={thtdStyle}>Age</th>
//             <th style={thtdStyle}>Department</th>
//             <th style={thtdStyle}>Gender</th>
//             <th style={thtdStyle}>Actions</th>
//           </tr>
//         </thead>
//         <tbody>
//           {users.map((user) => (
//             <tr key={user.id}>
//               <td style={thtdStyle}>{user.Id}</td>
//               <td style={thtdStyle}>{user.Name}</td>
//               <td style={thtdStyle}>{user.Email}</td>
//               <td style={thtdStyle}>{user.Age}</td>
//               <td style={thtdStyle}>{user.Department}</td>
//               <td style={thtdStyle}>{user.Gender}</td>
//               <td style={thtdStyle}>
//                 <button onClick={() => handleView(user)}>View</button>
//                 <button onClick={() => handleEdit(user)}>Edit</button>
//                 <button onClick={() => handleDelete(user.Id)}>Delete</button>
//               </td>
//             </tr>
//           ))}
//         </tbody>
//       </table>

//       {isPopupVisible && viewUser && (
//         <div className="popup">
//           <div className="popup-content">
//             <h3>User Details</h3>
//             <p>
//               <strong>Name :-</strong>
//               {viewUser.Name}
//             </p>
//             <p>
//               <strong>Email :-</strong>
//               {viewUser.Email}
//             </p>
//             <p>
//               <strong>Age :-</strong>
//               {viewUser.Age}
//             </p>
//             <p>
//               <strong>Department :-</strong>
//               {viewUser.Department}
//             </p>
//             <p>
//               <strong>Gender :-</strong>
//               {viewUser.Gender}
//             </p>
//             <button onClick={closePopup}>Close</button>
//           </div>
//         </div>
//       )}

//       {isEding && editUser && (
//         <div className="popup">
//           <div className="popup-content">
//             <form onSubmit={handleEditSubmit}>
//               <div>
//                 <label>Name</label>
//                 <input
//                   type="text"
//                   name="name"
//                   value={editUser.name}
//                   onChange={(e) =>
//                     setEditUser({ ...editUser, name: e.target.value })
//                   }
//                   required
//                 />
//               </div>

//               <div>
//                 <label>Email</label>
//                 <input
//                   type="email"
//                   name="email"
//                   value={editUser.email}
//                   onChange={(e) =>
//                     setEditUser({ ...editUser, email: e.target.value })
//                   }
//                   required
//                 />
//               </div>

//               <div>
//                 <label>Age</label>
//                 <input
//                   type="number"
//                   name="age"
//                   value={editUser.age}
//                   onChange={(e) =>
//                     setEditUser({ ...editUser, age: e.target.value })
//                   }
//                   required
//                 />
//               </div>

//               <div>
//                 <label>Department</label>
//                 <input
//                   type="text"
//                   name="department"
//                   value={editUser.department}
//                   onChange={(e) =>
//                     setEditUser({ ...editUser, department: e.target.value })
//                   }
//                 />
//               </div>

//               <div>
//                 <label>Gender</label>
//                 <select
//                   name="gender"
//                   value={editUser.gender}
//                   onChange={(e) =>
//                     setEditUser({ ...editUser, gender: e.target.value })
//                   }
//                   required
//                 >
//                   <option value="Male">Male</option>
//                   <option value="Female">Female</option>
//                   <option value="Other">Other</option>
//                 </select>
//               </div>

//               <button type="submit">Save Changes</button>
//               <button onClick={() => setIsEditing(false)}>Cansle</button>
//             </form>
//           </div>
//         </div>
//       )}

//       <br></br>
//       <br></br>
//       <h1>Second method of editing........................</h1>
//       <Edit />
//     </div>
//   );
// }

// export default App;

////---------------------------------------------------------------------------------------------------------------------------------------------------------------------////

import React, { useState, useEffect } from "react";
import logo from "./logo.svg";
import "./App.css";
import Edit from "./Edit.js";
import Login from "./Login.js";
import Profile from "./Profile.js";
import { BrowserRouter as Router, Route, Routes } from "react-router-dom";
import Signup from "./Signup.js";
function App() {
  const [user, setUser] = useState(null);
  return (
    <Router>
      <Routes>
        <Route path="/" element={<Login />} />
        <Route path="/signup" element={<Signup />} />

        <Route path="/myform" element={<Edit />} />
      </Routes>
    </Router>
  );
}

export default App;
