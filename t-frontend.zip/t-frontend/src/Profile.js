import React from "react";

const Profile = ({ user }) => {
  return (
    <div>
      <h1>..............User Profile........</h1>
      <p>
        <strong>ID :-</strong>
        {user.id}
      </p>
      <p>
        <strong>Email :-</strong>
        {user.email}
      </p>
    </div>
  );
};

export default Profile;
