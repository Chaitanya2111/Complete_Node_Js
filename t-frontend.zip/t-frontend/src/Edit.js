import React, { useState, useEffect } from "react";
import logo from "./logo.svg";
import "./App.css";
import axios from "axios";
import "./mycss.css";
import html2canvas from "html2canvas";
import jsPDF from "jspdf";
import { useNavigate } from "react-router-dom";
function Edit() {
  const [user, setUser] = useState({
    name: "",
    email: "",
    age: "",
    department: "",
    gender: "",
    document: null,
  });

  const [users, setUsers] = useState([]);
  const [viewUser, setViewUser] = useState(null);
  const [isPopupVisible, setIsPopupVisible] = useState(false);
  const [isEditing, setIsEditing] = useState(false);
  const [editUserId, setEditUserId] = useState(null);

  const navigate = useNavigate();
  const habdlebtnclick = () => {
    navigate("/");
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setUser({
      ...user,
      [name]: value,
    });
  };

  const handleFileChange = (e) => {
    setUser({
      ...user,
      document: e.target.files[0],
    });
  };

  //   const handleSubmit = async (e) => {
  //     e.preventDefault();
  //     try {
  //       await axios.post("http://localhost:5000/api/users", user);
  //       alert("User data submitted ");
  //     } catch (error) {
  //       console.log("we have error", error);
  //     }
  //   };

  // const handleSubmit = async (e) => {
  //   e.preventDefault();
  //   if (isEditing) {
  //     try {
  //       await axios.put(`http://localhost:5000/api/users/${editUserId}`, user);
  //       alert("user data updated...................");
  //     } catch (error) {
  //       console.log("we have error during put/ updated", error);
  //     }
  //     setIsEditing(false);
  //     setEditUserId(null);
  //   } else {
  //     try {
  //       await axios.post("http://localhost:5000/api/users", user);
  //       alert("user added successfully......................................");
  //     } catch (error) {
  //       console.log("we have error during post ");
  //     }
  //   }
  //   fetchUsers();
  //   setUser({
  //     name: "",
  //     email: "",
  //     age: "",
  //     department: "",
  //     gender: "",
  //   });
  // };

  const handleSubmit = async (e) => {
    e.preventDefault();

    const formData = new FormData();
    formData.append("name", user.name);
    formData.append("email", user.email);
    formData.append("age", user.age);
    formData.append("department", user.department);
    formData.append("gender", user.gender);

    if (user.document) {
      formData.append("document", user.document);
    }

    if (isEditing) {
      try {
        await axios.put(
          `http://localhost:5000/api/users/${editUserId}`,
          formData,
          {
            headers: {
              "Content-Type": "multipart/form-data",
            },
          }
        );
        alert("User data updated...");
      } catch (error) {
        console.log("error during update", error);
      }
      setIsEditing(false);
      setEditUserId(null);
    } else {
      try {
        await axios.post("http://localhost:5000/api/users", formData, {
          headers: { "Content-Type": "multipart/form-data" },
        });
        alert("user added successfully...");
      } catch (error) {
        console.log("error during post", error);
      }
    }
    fetchUsers();
    setUser({
      name: "",
      email: "",
      age: "",
      department: "",
      gender: "",
      document: null,
    });
  };

  // const fetchUsers = async () => {
  //   try {
  //     const response = await axios.get("http://localhost:5000/api/users");
  //     setUsers(response.data);
  //   } catch (error) {
  //     console.log("we have error", error);
  //   }
  // };

  const fetchUsers = async () => {
    try {
      const response = await axios.get("http://localhost:5000/api/users");
      const usersWithDocumentURL = response.data.map((user) => ({
        ...user,
        documentURL: `http://localhost:5000/uploads/${user.DocumentName}`,
      }));
      setUsers(usersWithDocumentURL);
    } catch (error) {
      console.log("we have error", error);
    }
  };

  const handleDelete = async (id) => {
    try {
      await axios.delete(`http://localhost:5000/api/userdelete/${id}`);
      alert("User data deleted ");
      fetchUsers();
    } catch (error) {
      console.log("there wase error during deleting user data", error);
    }
  };

  const handleView = (user) => {
    setViewUser(user);
    setIsPopupVisible(true);
  };

  const handleEdit = (user) => {
    setUser({
      name: user.Name,
      email: user.Email,
      age: user.Age,
      department: user.Department,
      gender: user.Gender,
      document: null,
    });
    setIsEditing(true);
    setEditUserId(user.Id);
  };

  const closePopup = () => {
    setIsPopupVisible(false);
    setViewUser(null);
  };

  useEffect(() => {
    fetchUsers();
  }, []);

  const generatePDF = () => {
    const input = document.body;
    // const input = document.getElementById("mytable");
    html2canvas(input)
      .then((canvas) => {
        const imgData = canvas.toDataURL("image/png");
        const pdf = new jsPDF();
        const imgProps = pdf.getImageProperties(imgData);
        const pdfWidth = pdf.internal.pageSize.getWidth();
        const pdfHeight = (imgProps.height * pdfWidth) / imgProps.width;
        pdf.addImage(imgData, "PNG", 0, 0, pdfWidth, pdfHeight);
        pdf.save("INSICODE.pdf");
      })
      .catch((error) => {
        console.error("error generating pdf", error);
      });
  };

  const donloadDocument = async (id) => {
    try {
      const response = await axios.get(
        `http://localhost:5000/api/downloads/${id}`,
        {
          responseType: "blob",
        }
      );
      const file = new Blob([response.data], { type: "application/pdf" });
      const fileURl = URL.createObjectURL(file);
      const link = document.createElement("a");
      link.href = fileURl;
      link.download = `Insicode_${id}.pdf`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    } catch (err) {
      console.log("error", err);
    }
  };

  const tableStyle = {
    // borderCollapse :'collapse',
    width: "100%",
    marginTop: "30px",
  };

  const thtdStyle = {
    border: "1px solid red",
    padding: "8px",
    textAlign: "left",
  };

  return (
    <div className="App">
      <h2>Send Users To database</h2>
      <form onSubmit={handleSubmit}>
        <div>
          <label>Name</label>
          <input
            type="text"
            name="name"
            required
            value={user.name}
            onChange={handleChange}
          />
        </div>

        <div>
          <label>Email</label>
          <input
            type="text"
            name="email"
            required
            value={user.email}
            onChange={handleChange}
          />
        </div>

        <div>
          <label>Age</label>
          <input
            type="number"
            name="age"
            required
            onChange={handleChange}
            value={user.age}
          />
        </div>

        <div>
          <label>Department</label>
          <input
            type="text"
            name="department"
            onChange={handleChange}
            value={user.department}
          />
        </div>

        <div>
          <label>Gender</label>
          <div>
            <input
              type="radio"
              id="male"
              name="gender"
              value="Male"
              onChange={handleChange}
              required
              checked={user.gender === "Male"}
            />
            <label>Male</label>
          </div>

          <div>
            <input
              type="radio"
              id="female"
              name="gender"
              value="Female"
              onChange={handleChange}
              required
              checked={user.gender === "Female"}
            />
            <label>Female</label>
          </div>

          <div>
            <input
              type="radio"
              id="other"
              name="gender"
              value="Other"
              onChange={handleChange}
              required
              checked={user.gender === "Other"}
            />
            <label>Other</label>
          </div>
        </div>

        <div>
          <label>Document</label>
          <input type="file" name="document" onChange={handleFileChange} />
        </div>

        <button type="submit">Submit</button>
      </form>

      <h2>Get users from database</h2>
      <table style={tableStyle} id="mytable">
        <thead>
          <tr>
            <th style={thtdStyle}>ID</th>
            <th style={thtdStyle}>Name</th>
            <th style={thtdStyle}>Email</th>
            <th style={thtdStyle}>Age</th>
            <th style={thtdStyle}>Department</th>
            <th style={thtdStyle}>Gender</th>
            <th style={thtdStyle}>Documents</th>
            <th style={thtdStyle}>Actions</th>
          </tr>
        </thead>
        <tbody>
          {users.map((user) => (
            <tr key={user.id}>
              <td style={thtdStyle}>{user.Id}</td>
              <td style={thtdStyle}>{user.Name}</td>
              <td style={thtdStyle}>{user.Email}</td>
              <td style={thtdStyle}>{user.Age}</td>
              <td style={thtdStyle}>{user.Department}</td>
              <td style={thtdStyle}>{user.Department}</td>
              <td style={thtdStyle}>
                {/* {user.documentURL && (
                  <img
                    src={user.documentURL}
                    alt="Document not found"
                    width="150"
                  />
                )} */}

                {user.documentURL && user.documentURL.endsWith(".pdf") ? (
                  <a
                    href={user.documentURL}
                    target="_blank"
                    rel="noopener noreferrer"
                  >
                    View pdf
                  </a>
                ) : (
                  <img
                    src={user.documentURL}
                    alt="Document not found"
                    width="150"
                  />
                )}
              </td>
              <td style={thtdStyle}>
                <button onClick={() => handleView(user)}>View</button>
                <button onClick={() => handleEdit(user)}>Edit</button>
                <button onClick={() => handleDelete(user.Id)}>Delete</button>

                {user.documentURL && user.documentURL.endsWith(".pdf") && (
                  <button onClick={() => donloadDocument(user.Id)}>
                    Download PDF
                  </button>
                )}
              </td>
            </tr>
          ))}
        </tbody>
      </table>

      {isPopupVisible && viewUser && (
        <div className="popup">
          <div className="popup-content">
            <h3>User Details</h3>
            <p>
              <strong>Name :-</strong>
              {viewUser.Name}
            </p>
            <p>
              <strong>Email :-</strong>
              {viewUser.Email}
            </p>
            <p>
              <strong>Age :-</strong>
              {viewUser.Age}
            </p>
            <p>
              <strong>Department :-</strong>
              {viewUser.Department}
            </p>
            <p>
              <strong>Gender :-</strong>
              {viewUser.Gender}
            </p>

            {viewUser.documentURL && (
              <img
                src={viewUser.documentURL}
                alt="document not found"
                width="200"
              />
            )}

            <br />
            <button onClick={closePopup}>Close</button>
          </div>
        </div>
      )}
      <br></br>
      <button onClick={habdlebtnclick}>Logout</button>
      <br></br>
      <button onClick={generatePDF}>GENERATE PDF</button>
    </div>
  );
}

export default Edit;
